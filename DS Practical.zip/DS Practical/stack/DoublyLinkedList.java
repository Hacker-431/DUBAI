/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stack;

/**
 *
 * @author kuldeep mishra
 */
import java.util.Scanner;

class DoublyLinkedList {

    static class Node {
        int data;
        Node prev, next;

        Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Node head = null;

        while (true) {
            System.out.println("\n1. Insert");
            System.out.println("2. Delete");
            System.out.println("3. Display");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter data: ");
                int data = sc.nextInt();
                Node newNode = new Node(data);

                if (head == null) {
                    head = newNode;
                } else {
                    Node temp = head;
                    while (temp.next != null) {
                        temp = temp.next;
                    }
                    temp.next = newNode;
                    newNode.prev = temp;
                }
                System.out.println("Inserted: " + data);
            }

            else if (choice == 2) {
                if (head == null) {
                    System.out.println("List is empty.");
                } else {
                    System.out.print("Enter data to delete: ");
                    int data = sc.nextInt();
                    Node temp = head;

                    if (temp.data == data) {
                        head = temp.next;
                        if (head != null) {
                            head.prev = null;
                        }
                        System.out.println("Deleted: " + data);
                    } else {
                        while (temp != null && temp.data != data) {
                            temp = temp.next;
                        }

                        if (temp == null) {
                            System.out.println("Element not found.");
                        } else {
                            if (temp.next != null) {
                                temp.next.prev = temp.prev;
                            }
                            if (temp.prev != null) {
                                temp.prev.next = temp.next;
                            }
                            System.out.println("Deleted: " + data);
                        }
                    }
                }
            }

            else if (choice == 3) {
                if (head == null) {
                    System.out.println("List is empty.");
                } else {
                    Node temp = head;
                    System.out.print("Doubly Linked List: ");
                    while (temp != null) {
                        System.out.print(temp.data + " <-> ");
                        temp = temp.next;
                    }
                    System.out.println("null");
                }
            }

            else if (choice == 4) {
                sc.close();
                break;
            }

            else {
                System.out.println("Invalid choice.");
            }
        }
    }
}

