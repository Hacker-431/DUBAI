/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stack;

/**
 *
 * @author kuldeep mishra
 */
import java.util.Scanner;

public class StackUsingArray {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the maximum size of the stack: ");
        int maxSize = scanner.nextInt();

        int[] stack = new int[maxSize];
        int top = -1;
        int choice;

        do {
            System.out.println("\nStack Operations:");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Peek");
            System.out.println("4. Check if Stack is Empty");
            System.out.println("5. Get Stack Size");
            System.out.println("6. Display Stack");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {

                case 1:
                    if (top == maxSize - 1) {
                        System.out.println("Stack Overflow. Cannot push.");
                    } else {
                        System.out.print("Enter element to push: ");
                        int data = scanner.nextInt();
                        stack[++top] = data;
                        System.out.println(data + " pushed to stack");
                    }
                    break;

                case 2:
                    if (top == -1) {
                        System.out.println("Stack Underflow. Nothing to pop.");
                    } else {
                        System.out.println(stack[top--] + " popped from stack");
                    }
                    break;

                case 3:
                    if (top == -1) {
                        System.out.println("Stack is empty. Nothing to peek.");
                    } else {
                        System.out.println("Top element is: " + stack[top]);
                    }
                    break;

                case 4:
                    if (top == -1) {
                        System.out.println("Stack is empty.");
                    } else {
                        System.out.println("Stack is not empty.");
                    }
                    break;

                case 5:
                    System.out.println("Size of stack: " + (top + 1));
                    break;

                case 6:
                    if (top == -1) {
                        System.out.println("Stack is empty.");
                    } else {
                        System.out.print("Stack elements: ");
                        for (int i = 0; i <= top; i++) {
                            System.out.print(stack[i] + " ");
                        }
                        System.out.println();
                    }
                    break;

                case 7:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 7);

        scanner.close();
    }
}

