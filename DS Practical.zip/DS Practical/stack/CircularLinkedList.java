/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stack;

/**
 *
 * @author kuldeep mishra
 */
import java.util.Scanner;

class CircularLinkedList {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Node last = null;

        while (true) {
            System.out.println("\n1. Insert");
            System.out.println("2. Delete");
            System.out.println("3. Display");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter data: ");
                int data = sc.nextInt();
                Node newNode = new Node(data);

                if (last == null) {
                    last = newNode;
                    last.next = last;
                } else {
                    newNode.next = last.next;
                    last.next = newNode;
                    last = newNode;
                }
                System.out.println("Inserted: " + data);
            }

            else if (choice == 2) {
                if (last == null) {
                    System.out.println("List is empty.");
                } else {
                    System.out.print("Enter data to delete: ");
                    int data = sc.nextInt();
                    Node curr = last.next;
                    Node prev = last;

                    if (curr == last && curr.data == data) {
                        last = null;
                        System.out.println("Deleted: " + data);
                    } else {
                        boolean found = false;
                        do {
                            if (curr.data == data) {
                                prev.next = curr.next;
                                if (curr == last) {
                                    last = prev;
                                }
                                System.out.println("Deleted: " + data);
                                found = true;
                                break;
                            }
                            prev = curr;
                            curr = curr.next;
                        } while (curr != last.next);

                        if (!found) {
                            System.out.println("Element not found.");
                        }
                    }
                }
            }

            else if (choice == 3) {
                if (last == null) {
                    System.out.println("List is empty.");
                } else {
                    System.out.print("Circular Linked List: ");
                    Node temp = last.next;
                    do {
                        System.out.print(temp.data + " -> ");
                        temp = temp.next;
                    } while (temp != last.next);
                    System.out.println("(back to head)");
                }
            }

            else if (choice == 4) {
                sc.close();
                break;
            }

            else {
                System.out.println("Invalid choice.");
            }
        }
    }
}

