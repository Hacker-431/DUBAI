/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stack;

/**
 *
 * @author kuldeep mishra
 */
import java.util.Scanner;

class SinglyLinkedList {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Node head = null;

        while (true) {
            System.out.println("\n1. Insert");
            System.out.println("2. Delete");
            System.out.println("3. Display");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter data: ");
                int data = sc.nextInt();
                Node newNode = new Node(data);

                if (head == null) {
                    head = newNode;
                } else {
                    Node temp = head;
                    while (temp.next != null) {
                        temp = temp.next;
                    }
                    temp.next = newNode;
                }
                System.out.println("Inserted: " + data);
            }

            else if (choice == 2) {
                if (head == null) {
                    System.out.println("List is empty.");
                } else {
                    System.out.print("Enter data to delete: ");
                    int data = sc.nextInt();

                    if (head.data == data) {
                        head = head.next;
                        System.out.println("Deleted: " + data);
                    } else {
                        Node temp = head;
                        while (temp.next != null && temp.next.data != data) {
                            temp = temp.next;
                        }

                        if (temp.next == null) {
                            System.out.println("Element not found.");
                        } else {
                            temp.next = temp.next.next;
                            System.out.println("Deleted: " + data);
                        }
                    }
                }
            }

            else if (choice == 3) {
                if (head == null) {
                    System.out.println("List is empty.");
                } else {
                    Node temp = head;
                    System.out.print("Singly Linked List: ");
                    while (temp != null) {
                        System.out.print(temp.data + " -> ");
                        temp = temp.next;
                    }
                    System.out.println("null");
                }
            }

            else if (choice == 4) {
                sc.close();
                break;
            }

            else {
                System.out.println("Invalid choice.");
            }
        }
    }
}

