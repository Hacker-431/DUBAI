package com.mycompany.sparsematrix;
import java.util.Scanner;
class SparseNode {
    int row, col, value;
    SparseNode next;
    SparseNode(int r, int c, int v) {
        row = r;
        col = c;
        value = v;
        next = null;
    }
}
public class SparseMatrix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SparseNode head = null, tail = null;
        System.out.print("Enter number of non-zero elements: ");
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            System.out.print("Enter row, column and value: ");
            int r = sc.nextInt();
            int c = sc.nextInt();
            int v = sc.nextInt();
            SparseNode node = new SparseNode(r, c, v);
            if (head == null) {
                head = tail = node;
            } else {
                tail.next = node;
                tail = node;
            }
        }
        System.out.println("\nSparse Matrix Representation (Row Col Value):");
        SparseNode temp = head;
        while (temp != null) {
            System.out.println(temp.row + " " + temp.col + " " + temp.value);
            temp = temp.next;
        }
    }
}
