package com.mycompany.primmst;
import java.util.*;
public class PrimMST {
    static class Edge {
        int v, parent, weight;
        Edge(int v, int parent, int weight) {
            this.v = v;
            this.parent = parent;
            this.weight = weight;
        }
    }
    public static void primMST(int V, List<List<int[]>> adj) {
        boolean[] visited = new boolean[V];
        PriorityQueue<Edge> pq =
                new PriorityQueue<>(Comparator.comparingInt(e -> e.weight));
        pq.add(new Edge(0, -1, 0)); 
        int totalWeight = 0;
        System.out.println("Edges in MST:");
        while (!pq.isEmpty()) {
            Edge curr = pq.poll();
            int u = curr.v;
            if (visited[u]) continue;
            visited[u] = true;
            totalWeight += curr.weight;
            if (curr.parent != -1) {
                System.out.println(
                        curr.parent + " - " + u + "  weight = " + curr.weight
                );
            }
            for (int[] nbr : adj.get(u)) {
                int v = nbr[0];
                int w = nbr[1];
                if (!visited[v]) {
                    pq.add(new Edge(v, u, w));
                }
            }
        }
        System.out.println("Total weight of MST = " + totalWeight);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of vertices (V): ");
        int V = sc.nextInt();
        System.out.print("Enter number of edges (E): ");
        int E = sc.nextInt();
        List<List<int[]>> adj = new ArrayList<>();
        for (int i = 0; i < V; i++) {
            adj.add(new ArrayList<>());
        }
        System.out.println("Enter edges (u v weight):");
        for (int i = 0; i < E; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            int w = sc.nextInt();
            adj.get(u).add(new int[]{v, w});
            adj.get(v).add(new int[]{u, w});
        }
        primMST(V, adj);
        sc.close();
    }
}
