/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.stack;

/**
 *
 * @author kuldeep mishra
 */
import java.util.Scanner;

public class Stack {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter size of stack: ");
        int size = sc.nextInt();
        int[] stack = new int[size];
        int top = -1; // stack is initially empty

        int choice;

        do {
            System.out.println("--- Stack Menu ---");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Peek ");
            System.out.println("4. Display Stack");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            choice = sc.nextInt();

            switch (choice) {
                case 1: // Push
                    if (top == size - 1) {
                        System.out.println("Stack Overflow! Cannot push element.");
                    } else {
                        System.out.print("Enter element to push: ");
                        int num = sc.nextInt();
                        top++;
                        stack[top] = num;
                        System.out.println(num + " pushed into stack.");
                    }
                    break;

                case 2: // Pop
                    if (top == -1) {
                        System.out.println("Stack Underflow! No elements to pop.");
                    } else {
                        System.out.println(stack[top] + " popped from stack.");
                        top--;
                    }
                    break;

                case 3: // Peek
                    if (top == -1) {
                        System.out.println("Stack is empty. No top element.");
                    } else {
                        System.out.println("Top element is: " + stack[top]);
                    }
                    break;

                case 4: // Display
                    if (top == -1) {
                        System.out.println("Stack is empty.");
                    } else {
                        System.out.print("Stack elements: ");
                        for (int i = 0; i <= top; i++) {
                            System.out.print(stack[i] + " ");
                        }
                        System.out.println();
                    }
                    break;

                case 5:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 5);

        sc.close();
    }
}


