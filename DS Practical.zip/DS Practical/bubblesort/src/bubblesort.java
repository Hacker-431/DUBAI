public class bubblesort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] arr = {64, 34, 25, 12, 122};

        System.out.println("Original array:");
        printArray(arr);

        bubbleSortWithSteps(arr);

        System.out.println("Sorted array:");
        printArray(arr);

    }
    public static void bubbleSortWithSteps(int[] arr) {
        int n = arr.length;
        boolean swapped;

        for (int i = 0; i < n - 1; i++)
        {
            swapped = false;
            System.out.println("\nPass" + (i + 1) + ":");
            for (int j = 0; j < n - 1 - i; j++)
            {
                if (arr[j] > arr[j + 1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
                printArray(arr);
            }
            if (!swapped){
                System.out.println("No swaps needed.Array");
                break;
            }
        }
    }

    public static void printArray(int[] arr) {

        for (int num : arr) {
            System.out.print(num + " ");//To change body of generated methods, choose Tools | Templates.
        }
        System.out.println();
    }
}
