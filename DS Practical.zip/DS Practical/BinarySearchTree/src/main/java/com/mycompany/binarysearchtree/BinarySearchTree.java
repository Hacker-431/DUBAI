package com.mycompany.binarysearchtree;
import java.util.Scanner;
class Node {
    int data;
    Node left, right;
    Node(int value) {
        data = value;
        left = right = null;
    }
}
public class BinarySearchTree {
    Node root;
    Node insert(Node root, int value) {
        if (root == null)
            return new Node(value);
        if (value < root.data)
            root.left = insert(root.left, value);
        else if (value > root.data)
            root.right = insert(root.right, value);
        return root;
    }
    Node delete(Node root, int key) {
        if (root == null)
            return root;
        if (key < root.data)
            root.left = delete(root.left, key);
        else if (key > root.data)
            root.right = delete(root.right, key);
        else {
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;
            root.data = minValue(root.right);
            root.right = delete(root.right, root.data);
        }
        return root;
    }
    int minValue(Node root) {
        int min = root.data;
        while (root.left != null) {
            min = root.left.data;
            root = root.left;
        }
        return min;
    }
    int height(Node root) {
        if (root == null)
            return -1;
        return 1 + Math.max(height(root.left), height(root.right));
    }
    void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }
    void preorder(Node root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }
    }
    void postorder(Node root) {
        if (root != null) {
            postorder(root.left);
            postorder(root.right);
            System.out.print(root.data + " ");
        }
    }
    int findMax(Node root) {
        if (root == null)
            return -1;

        while (root.right != null)
            root = root.right;
        return root.data;
    }
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        Scanner sc = new Scanner(System.in);
        int choice, value;
        do {
            System.out.println("\n--- Binary Search Tree Menu ---");
            System.out.println("1. Insert");
            System.out.println("2. Delete");
            System.out.println("3. Inorder Traversal");
            System.out.println("4. Preorder Traversal");
            System.out.println("5. Postorder Traversal");
            System.out.println("6. Height of Tree");
            System.out.println("7. Maximum Value");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter value to insert: ");
                    value = sc.nextInt();
                    bst.root = bst.insert(bst.root, value);
                    break;
                case 2:
                    System.out.print("Enter value to delete: ");
                    value = sc.nextInt();
                    bst.root = bst.delete(bst.root, value);
                    break;
                case 3:
                    System.out.print("Inorder Traversal: ");
                    bst.inorder(bst.root);
                    System.out.println();
                    break;
                case 4:
                    System.out.print("Preorder Traversal: ");
                    bst.preorder(bst.root);
                    System.out.println();
                    break;
                case 5:
                    System.out.print("Postorder Traversal: ");
                    bst.postorder(bst.root);
                    System.out.println();
                    break;
                case 6:
                    System.out.println("Height of Tree: " + bst.height(bst.root));
                    break;
                case 7:
                    System.out.println("Maximum Value: " + bst.findMax(bst.root));
                    break;
                case 8:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 8);
        sc.close();
    }
}
