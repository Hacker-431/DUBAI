package com.mycompany.polynomialaddition;
import java.util.Scanner;
class PolyNode {
    int coeff, power;
    PolyNode next;
    PolyNode(int c, int p) {
        coeff = c;
        power = p;
        next = null;
    }
}
public class PolynomialAddition {
    static PolyNode createPoly(int n, Scanner sc) {
        PolyNode head = null, tail = null;
        for (int i = 0; i < n; i++) {
            System.out.print("Enter coefficient and power: ");
            int c = sc.nextInt();
            int p = sc.nextInt();
            PolyNode newNode = new PolyNode(c, p);
            if (head == null) {
                head = tail = newNode;
            } else {
                tail.next = newNode;
                tail = newNode;
            }
        }
        return head;
    }
    static PolyNode addPoly(PolyNode p1, PolyNode p2) {
        PolyNode result = null, tail = null;

        while (p1 != null && p2 != null) {
            int c, p;
            if (p1.power == p2.power) {
                c = p1.coeff + p2.coeff;
                p = p1.power;
                p1 = p1.next;
                p2 = p2.next;
            } else if (p1.power > p2.power) {
                c = p1.coeff;
                p = p1.power;
                p1 = p1.next;
            } else {
                c = p2.coeff;
                p = p2.power;
                p2 = p2.next;
            }

            PolyNode node = new PolyNode(c, p);
            if (result == null) result = tail = node;
            else {
                tail.next = node;
                tail = node;
            }
        }
        return result;
    }
    static void display(PolyNode p) {
        while (p != null) {
            System.out.print(p.coeff + "x^" + p.power);
            if (p.next != null) System.out.print(" + ");
            p = p.next;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of terms in Polynomial 1: ");
        int n1 = sc.nextInt();
        PolyNode p1 = createPoly(n1, sc);
        System.out.print("Enter number of terms in Polynomial 2: ");
        int n2 = sc.nextInt();
        PolyNode p2 = createPoly(n2, sc);
        PolyNode sum = addPoly(p1, p2);
        System.out.print("Resultant Polynomial: ");
        display(sum);
    }
}

