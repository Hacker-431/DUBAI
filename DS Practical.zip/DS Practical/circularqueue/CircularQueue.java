/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.circularqueue;

/**
 *
 * @author kuldeep mishra
 */


import java.util.Scanner;

public class CircularQueue{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the queue: ");
        int n = scanner.nextInt();
        int size = n + 1; // +1 to differentiate full vs empty
        int[] queue = new int[size];
        int front = 0, rear = 0;
        int choice;

        while (true) {
            System.out.println("\nChoose an operation:");
            System.out.println("1. Enqueue");
            System.out.println("2. Dequeue");
            System.out.println("3. Peek");
            System.out.println("4. Display");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    if ((rear + 1) % size == front) {
                        System.out.println("Queue is full. Cannot enqueue.");
                    } else {
                        System.out.print("Enter element to enqueue: ");
                        int element = scanner.nextInt();
                        queue[rear] = element;
                        rear = (rear + 1) % size;
                        System.out.println("Enqueued: " + element);
                    }
                    break;

                case 2:
                    if (front == rear) {
                        System.out.println("Queue is empty. Cannot dequeue.");
                    } else {
                        int element = queue[front];
                        front = (front + 1) % size;
                        System.out.println("Dequeued: " + element);
                    }
                    break;

                case 3:
                    if (front == rear) {
                        System.out.println("Queue is empty. Cannot peek.");
                    } else {
                        System.out.println("Front element: " + queue[front]);
                    }
                    break;

                case 4:
                    if (front == rear) {
                        System.out.println("Queue is empty.");
                    } else {
                        System.out.print("Queue: ");
                        int i = front;
                        while (i != rear) {
                            System.out.print(queue[i] + " ");
                            i = (i + 1) % size;
                        }
                        System.out.println();
                    }
                    break;

                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}

