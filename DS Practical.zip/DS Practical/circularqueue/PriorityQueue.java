/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.circularqueue;

/**
 *
 * @author kuldeep mishra
 */
import java.util.Scanner;

public class PriorityQueue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter maximum size of the priority queue: ");
        int n = scanner.nextInt();

        int[] values = new int[n];
        int[] priorities = new int[n];
        int size = 0;

        while (true) {
            System.out.println("\nChoose an operation:");
            System.out.println("1. Enqueue (Add Element)");
            System.out.println("2. Dequeue (Remove Highest Priority)");
            System.out.println("3. Peek (View Highest Priority)");
            System.out.println("4. Display All Elements");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    if (size == n) {
                        System.out.println("Queue is full. Cannot enqueue.");
                    } else {
                        System.out.print("Enter value: ");
                        int value = scanner.nextInt();
                        System.out.print("Enter priority: ");
                        int priority = scanner.nextInt();

                        // Insert element in priority order (highest first)
                        int i;
                        for (i = size - 1; i >= 0; i--) {
                            if (priority > priorities[i]) {
                                values[i + 1] = values[i];
                                priorities[i + 1] = priorities[i];
                            } else {
                                break;
                            }
                        }
                        values[i + 1] = value;
                        priorities[i + 1] = priority;
                        size++;
                        System.out.println("Enqueued: " + value + " with priority " + priority);
                    }
                    break;

                case 2:
                    if (size == 0) {
                        System.out.println("Queue is empty. Cannot dequeue.");
                    } else {
                        System.out.println("Dequeued: Value: " + values[0] + ", Priority: " + priorities[0]);
                        // Shift all elements left
                        for (int i = 1; i < size; i++) {
                            values[i - 1] = values[i];
                            priorities[i - 1] = priorities[i];
                        }
                        size--;
                    }
                    break;

                case 3:
                    if (size == 0) {
                        System.out.println("Queue is empty. Cannot peek.");
                    } else {
                        System.out.println("Highest Priority Element: Value: " + values[0] + ", Priority: " + priorities[0]);
                    }
                    break;

                case 4:
                    if (size == 0) {
                        System.out.println("Queue is empty.");
                    } else {
                        System.out.println("All elements in priority queue:");
                        for (int i = 0; i < size; i++) {
                            System.out.println("Value: " + values[i] + ", Priority: " + priorities[i]);
                        }
                    }
                    break;

                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
