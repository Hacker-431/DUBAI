package com.mycompany.heap;
import java.util.Scanner;
public class Heap {
    int[] heap;
    int size;
    int capacity;
    Heap(int capacity) {
        this.capacity = capacity;
        heap = new int[capacity];
        size = 0;
    }
    void insert(int value) {
        if (size == capacity) {
            System.out.println("Heap is full");
            return;
        }
        heap[size] = value;
        int i = size;
        size++;
        while (i != 0 && heap[parent(i)] < heap[i]) {
            swap(i, parent(i));
            i = parent(i);
        }
    }
    void heapify(int i) {
        int largest = i;
        int left = leftChild(i);
        int right = rightChild(i);
        if (left < size && heap[left] > heap[largest])
            largest = left;
        if (right < size && heap[right] > heap[largest])
            largest = right;
        if (largest != i) {
            swap(i, largest);
            heapify(largest);
        }
    }
    void buildHeap() {
        for (int i = size / 2 - 1; i >= 0; i--) {
            heapify(i);
        }
    }
    void heapSort() {
        buildHeap();
        int originalSize = size;
        for (int i = size - 1; i > 0; i--) {
            swap(0, i);
            size--;
            heapify(0);
        }
        size = originalSize;
        System.out.print("Sorted Array: ");
        for (int i = 0; i < size; i++)
            System.out.print(heap[i] + " ");
        System.out.println();
    }
    void delete(int value) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (heap[i] == value) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            System.out.println("Value not found");
            return;
        }
        heap[index] = heap[size - 1];
        size--;
        heapify(index);
        System.out.println("Value deleted");
    }
    void display() {
        System.out.print("Heap elements: ");
        for (int i = 0; i < size; i++)
            System.out.print(heap[i] + " ");
        System.out.println();
    }
    int parent(int i) { return (i - 1) / 2; }
    int leftChild(int i) { return 2 * i + 1; }
    int rightChild(int i) { return 2 * i + 2; }
    void swap(int i, int j) {
        int temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter heap capacity: ");
        int cap = sc.nextInt();
        Heap h = new Heap(cap);
        int choice, value;
        do {
            System.out.println("\n--- Heap Menu ---");
            System.out.println("1. Insert");
            System.out.println("2. Build Heap (Heapify)");
            System.out.println("3. Heap Sort");
            System.out.println("4. Delete value");
            System.out.println("5. Display Heap");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter value: ");
                    value = sc.nextInt();
                    h.insert(value);
                    break;
                case 2:
                    h.buildHeap();
                    System.out.println("Heap created using heapify");
                    break;
                case 3:
                    h.heapSort();
                    break;
                case 4:
                    System.out.print("Enter value to delete: ");
                    value = sc.nextInt();
                    h.delete(value);
                    break;
                case 5:
                    h.display();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        } while (choice != 6);
        sc.close();
    }
}
