/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.searching;

/**
 *
 * @author kuldeep mishra
 */
public class Searching {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
