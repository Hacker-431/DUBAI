package com.mycompany.graphtraversal;
import java.util.*;
public class GraphTraversal {
    private int V; 
    private List<List<Integer>> adj; 
    // Constructor
    public GraphTraversal(int V) {
        this.V = V;
        adj = new ArrayList<>();
        for (int i = 0; i < V; i++) {
            adj.add(new ArrayList<>());
        }
    }
    public void addEdge(int u, int v) {
        adj.get(u).add(v);
        adj.get(v).add(u);
    }
    private void DFSUtil(int u, boolean[] visited) {
        visited[u] = true;
        System.out.print(u + " ");
        for (int v : adj.get(u)) {
            if (!visited[v]) DFSUtil(v, visited);
        }
    }
    public void DFS(int start) {
        boolean[] visited = new boolean[V];
        System.out.print("DFS Traversal starting from vertex " + start + ": ");
        DFSUtil(start, visited);
        System.out.println();
    }
    public void BFS(int start) {
        boolean[] visited = new boolean[V];
        Queue<Integer> q = new LinkedList<>();
        visited[start] = true;
        q.add(start);
        System.out.print("BFS Traversal starting from vertex " + start + ": ");
        while (!q.isEmpty()) {
            int u = q.poll();
            System.out.print(u + " ");
            for (int v : adj.get(u)) {
                if (!visited[v]) {
                    visited[v] = true;
                    q.add(v);
                }
            }
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of vertices: ");
        int V = sc.nextInt();
        System.out.print("Enter number of edges: ");
        int E = sc.nextInt();
        GraphTraversal g = new GraphTraversal(V);
        System.out.println("Enter edges (u v):");
        for (int i = 0; i < E; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            g.addEdge(u, v);
        }
        while (true) {
            System.out.println("\n--- Graph Traversal Menu ---");
            System.out.println("1. Depth First Search (DFS)");
            System.out.println("2. Breadth First Search (BFS)");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            if (choice == 3) break;
            System.out.print("Enter starting vertex: ");
            int start = sc.nextInt();
            switch (choice) {
                case 1 -> g.DFS(start);
                case 2 -> g.BFS(start);
                default -> System.out.println("Invalid choice!");
            }
        }
        sc.close();
        System.out.println("Program exited.");
    }
}
